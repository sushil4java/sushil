// var x = 10;
// function test() {
//   console.log(x);
//   var x = 20;
// }
// test();

// console.log(a);

// var a = 10;

// for (let i = 0; i <= 10; i++) {
//   setTimeout(() => {
//     console.log(i);
//   }, 2000);
// }

const data = ["Pune", "Mumbai", "Jaipur", "Mumbai", "Pune", "Pune", "Pune"];

const count = {};

for (const element of data) {
    console.log(element)
    console.log(count[element])
  if (count[element]) {
    count[element] += 1;
  } else {
    count[element] = 1;
  }
}
 console.log(count);
