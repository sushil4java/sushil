const app = require("express");

app.listen(4000, () => {
  console.log("connected to server on port 4000");
});

app.get("/", (req, res) => {
  res.send("server is up");
});

const routes = require("./routes/routes");

app.use("/routes", routes);
