import logo from "./logo.svg";
import "./App.css";
import { useSelector, useDispatch } from "react-redux";
import { changeUsersName, changeUsersAge } from "./Redux/actions/userActions";
import {
  addFruitsName,
  addFruitsQuantity,
} from "./Redux/actions/fruitsActions";
import InventoryComponent from "./components/inventoryComponent";
import { addData, deleteData } from "./Redux/actions/thunkAction";

import { useState } from "react";

function App() {
  const user = useSelector((state) => state.userReducer);
  const fruit = useSelector((state) => state.fruitReducer);

  const dispatch = useDispatch();

  const [name, setName] = useState(user.name);
  const [age, setAge] = useState(user.age);
  const [fname, setFname] = useState(fruit.fname);
  const [quantity, setQuantity] = useState(fruit.quantity);

  // Selects the state value from the store.
  const todo = useSelector((state) => state.thunkdataReducer.todo);
  // Dispatches action to add the data
  const handleAddData = () => dispatch(addData());
  // Dispatches action to delete the data.
  const handleDeleteData = () => dispatch(deleteData());

  return (
    <div className="App">
      <div>
        <button onClick={handleAddData}>Add Data</button>
        <button onClick={handleDeleteData}>Delete Data</button>

        {todo && <div>{JSON.stringify(todo)}</div>}
      </div>
      <InventoryComponent />
      <hr />
      {fruit.fname},{fruit.quantity}
      <input
        onChange={(e) => setFname(e.target.value)}
        placeholder="Change Fruit name"
      ></input>
      <input
        onChange={(e) => setQuantity(e.target.value)}
        placeholder="Change Fruit quantity"
      ></input>
      <h1>Name: {user.name}</h1>
      <h1>Age: {user.age}</h1>
      <hr></hr>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          dispatch(addFruitsName(fname));
          dispatch(addFruitsQuantity(quantity));
          dispatch(changeUsersName(name));
          dispatch(changeUsersAge(age));
        }}
      >
        <input
          onChange={(e) => setName(e.target.value)}
          placeholder="Change name"
        ></input>
        <input
          onChange={(e) => setAge(e.target.value)}
          placeholder="Change age"
        ></input>
        <input type="submit" value="Change user details" />
      </form>
    </div>
  );
}

export default App;
