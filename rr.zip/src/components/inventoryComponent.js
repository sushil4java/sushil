import React, { useState } from 'react';
import { useSelector, useDispatch } from "react-redux";
import { addToInventory, removeFromInventory, editFromInventory, addQuantity, emptyInventory } from '../Redux/actions/inventoryAction';


function InventoryComponent() {

    const [inventoryID, setInventoryID] = useState({})
    const [inventoryName, setInventoryName] = useState({})
    const [inventoryPrice, setInventoryPrice] = useState({})
    const [inventoryQuantity, setInventoryQuantity] = useState({})
    const [editIndex, setEditIndex] = useState({})

    const dispatch = useDispatch();
    const inventory = useSelector((state) => state.inventoryReducer);
    console.log(inventory)
    const save = () => {
        dispatch(addToInventory({
            "id": inventoryID,
            "name": inventoryName,
            "price": inventoryPrice,
            "quantity": inventoryQuantity
        }))

    }
    const saveEdit = () => {
        dispatch(editFromInventory({
            "id": inventoryID,
            "name": inventoryName,
            "price": inventoryPrice,
            "quantity": inventoryQuantity
        }, editIndex));
        setEditIndex(false)

    }
    const setEdit = (i, id, name, price, quantity) => {
        setEditIndex(i)
        setInventoryID(id)
        setInventoryName(name)
        setInventoryPrice(price)
        setInventoryQuantity(quantity)

    }

    const remove = (id) => {
        dispatch(removeFromInventory(id))
    }
    return (
        <div>
            <table>
                <thead>
                    <tr>
                        <th>
                            Id
                        </th>
                        <th>
                            Name
                        </th>

                        <th>
                            Price
                        </th>
                        <th>Quantity</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    {inventory.products.map((a, i) => (

                        <tr key={i}>

                            {editIndex === i ? <>

                                <td>
                                    <input
                                        value={inventoryID}
                                        onChange={(e) => setInventoryID(e.target.value)}
                                        placeholder="product id"
                                    ></input>
                                </td>
                                <td>
                                    <input
                                        value={inventoryName}
                                        onChange={(e) => setInventoryName(e.target.value)}
                                        placeholder="product name"
                                    ></input>
                                </td>

                                <td>
                                    <input
                                        value={inventoryPrice}
                                        onChange={(e) => setInventoryPrice(e.target.value)}
                                        placeholder="product price"
                                    ></input>
                                </td>
                                <td>
                                    <input
                                        value={inventoryQuantity}
                                        onChange={(e) => setInventoryQuantity(e.target.value)}
                                        placeholder="product quantity"
                                    ></input>
                                </td>
                                <td>

                                    <button onClick={() => saveEdit()} >save</button>
                                </td></> :
                                <>
                                    <td>{a.id}</td>
                                    <td>{a.name}</td>

                                    <td>{a.price}</td>
                                    <td>{a.quantity}</td>
                                    <td><button onClick={() => remove(i)}>Remove</button>
                                        <button onClick={() => setEdit(i, a.id, a.name, a.price, a.quantity)}>Edit</button></td>
                                </>
                            }

                        </tr>
                    ))}
                    <tr>
                        <td>
                            <input
                                onChange={(e) => setInventoryID(e.target.value)}
                                placeholder="product id"
                            ></input>
                        </td>
                        <td>
                            <input
                                onChange={(e) => setInventoryName(e.target.value)}
                                placeholder="product name"
                            ></input>
                        </td>
                        <td>
                            <input
                                onChange={(e) => setInventoryPrice(e.target.value)}
                                placeholder="product price"
                            ></input>
                        </td>

                        <td>
                            <input
                                onChange={(e) => setInventoryQuantity(e.target.value)}
                                placeholder="product quantity"
                            ></input>
                        </td>

                        <td>

                            <button onClick={() => save()} >Add in Inventory</button>
                        </td>
                    </tr>
                </tbody>
            </table>




        </div>
    )
}





export default InventoryComponent;