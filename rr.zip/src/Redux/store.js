import userReducer from "./reducers/userReducer";
import fruitReducer from "./reducers/fruitReducer";
import inventoryReducer from "./reducers/inventoryReducer";
import { configureStore, applyMiddleware } from "@reduxjs/toolkit";
import createSagaMiddleware from "redux-saga";
import thunk from 'redux-thunk';
import thunkdataReducer from "./reducers/thunkReducer";
import { helloSaga } from './saga' 

const sagaMiddleware = createSagaMiddleware();
const store = configureStore({
  reducer: {
    userReducer,
    fruitReducer,
    inventoryReducer,
    thunkdataReducer
   
  },
  middleware: [sagaMiddleware,thunk]
});
sagaMiddleware.run(helloSaga)  
export default store;
