export const addToInventory = product => {
  return {
    type: "ADD_TO_INVENTORY",
    product
  };
};
export const removeFromInventory = id => {
  return {
    type: "REMOVE_FROM_INVENTORY",
    id,
  };
};
export const editFromInventory = (product,id) => {
  return {
    type: "EDIT_INVENTORY",
    product,
    id
  };
};
export const addQuantity = id => {
  return {
    type: "ADD_QUANTITY",
    id,
  };
};
export const emptyInventory = () => {
  return {
    type: "EMPTY_INVENTORY",
  };
}