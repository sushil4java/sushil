export const addFruitsName = (fname) => {
  return {
    type: "FRUITSNAME",
    payload: fname,
  };
};
export const addFruitsQuantity = (quantity) => {
  return {
    type: "FRUITSQT",
    payload: quantity
  };
};