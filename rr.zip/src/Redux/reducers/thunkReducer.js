const INITAL_STATE = {
  todo: "",
};

const thunkdataReducer = (state = INITAL_STATE, action) => {
  switch (action.type) {
    case "ADD_DATA":
      return { ...state, todo: action.payload };
    case "DELETE_DATE":
      return { ...state, todo: INITAL_STATE };
  }
  return state;
};

export default thunkdataReducer;
