const initialState = {
    products: [{
        "id": 1,
        "name": "Perfume",
        "price": 200,
        "quantity": 1
    }],
};
const inventoryReducer = (state = initialState, action) => {
    // console.log("action", action)
    // console.log("state", state)
    switch (action.type) {
        case "ADD_TO_INVENTORY":
            return {
                ...state,
                products: [...state.products, action.product]

            };
        case "REMOVE_FROM_INVENTORY":
            return {
                ...state,
                // products: delete state.products[action.id]
                //products: state.products.splice(action.id, 1)
                //products: [...state.products.slice(action.id,1)]
                products: [...state.products.filter((obj, i) => i !== action.id)]
                //products: [...state.products.filter((obj) => obj.id !== action.id)]
            };

        case "EDIT_INVENTORY":
            return {
                ...state,
                // products: [...state.products.filter((obj, i) => i !== action.id), action.product]
                products: [...state.products.map((obj, i) => i === action.id ? action.product : obj)]
            };
        case "EMPTY_INVENTORY":
            return {
                ...state,
                products: state.products.map(product =>
                    product.selected
                        ? { ...product, selected: false, quantity: 1 }
                        : product,
                ),
            };
        case "ADD_QUANTITY":
            return {
                ...state,
                products: state.products.map(product =>
                    product.id === action.id
                        ? { ...product, quantity: product.quantity + 1 }
                        : product,
                ),
            };
    }
    return state;
};
export default inventoryReducer;
