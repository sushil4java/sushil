const inititalState = { fname: "Apple", quantity: 1 };
const fruitReducer = (state = inititalState, action) => {
    switch (action.type) {

        case "FRUITSNAME": {
            return { ...state, fname: action.payload };
        }
        case "FRUITSQT": {
            return { ...state, quantity: action.payload };
        }
    }
    return state;
};
export default fruitReducer;