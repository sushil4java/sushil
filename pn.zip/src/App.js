import "./App.css";
import Clock from "./components/watch";
import Rating from "./components/rating";
import Array from "./components/Array";
import Basics from "./components/basics";
import ReactBasics from "./components/React";
import Redux from "./components/Redux";
import Html from "./components/Html";
import Css from "./components/Css";
import { useState } from "react";

function App() {
  const [page, setPage] = useState("Array");
  let menu = [
    "ReactBasics",
    "JsBasics",
    "Array",
    "Rating",
    "Clock",
    "Html",
    "Css",
    "Redux",
  ];

  return (
    <div className="App">
      <div className="container">
        <ul className="nav nav-tabs">
          {menu.map((val, i) => (
            <li className="nav-item" key={i}>
              <a className="nav-link" onClick={() => setPage(val)}>
                {val}
              </a>
            </li>
          ))}
        </ul>

        {page === "Array" ? (
          <Array />
        ) : page === "Clock" ? (
          <Clock />
        ) : page === "JsBasics" ? (
          <Basics />
        ) : page === "ReactBasics" ? (
          <ReactBasics />
        ) : page === "Html" ? (
          <Html />
        ) : page === "Css" ? (
          <Css />
        ) : page === "Redux" ? (
          <Redux />
        ) : (
          <Rating />
        )}
      </div>
    </div>
  );
}

export default App;
