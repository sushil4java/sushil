import React, { useEffect, useState } from "react";

const Array = () => {
  const [value, setValue] = useState(1);
  const [arr, setArr] = useState([1, 2, 2, 3, 45, 55, 65, 90, 2, 45]);

  const [arr2, setArr2] = useState([
    "this",
    "is",
    "array",
    "methods",
    "learning",
  ]);

  const ArrayMethod = (method) => {
    let array = arr;

    if (method === "push") {
      array.push(value);
    }
    if (method === "pop") {
      array.pop();
    }
    if (method === "shift") {
      array.shift();
    }
    if (method === "unshift") {
      array.unshift(value);
    }
    setArr([...array]);

    if (method === "unique") {
      let result = [];
      for (let str of array) {
        if (!result.includes(str)) {
          result.push(str);
        }
      }
      setArr(result);
    }

    if (method === "dublicate") {
      setArr([...array.filter((item, i) => i !== array.indexOf(item))]);
    }

    if (method === "ascending") {
      setArr([
        ...array.sort((a, i) => {
          return a - i;
        }),
      ]);
    }

    if (method === "decending") {
      setArr([
        ...array.sort((a, i) => {
          return i - a;
        }),
      ]);
    }
  };

  const ArrayMethod2 = (method) => {
    let array = arr2;
    if (method === "splice5") {
      array.splice(0, 1);
    }
    if (method === "splice") {
      array.splice(1, 1);
    }
    if (method === "splice2") {
      array.splice(1, 2);
    }
    if (method === "splice3") {
      array.splice(2, 1);
    }
    if (method === "splice4") {
      array.splice(2, 2);
    }
    if (method === "splice6") {
      array.splice(2, 2, "X", "y");
    }

    setArr2([...array]);

    if (method === "slice") {
      setArr2(array.slice(0, 3));
    }
    if (method === "slice2") {
      setArr2(array.slice(0, 1));
    }

    if (method === "slice3") {
      console.log(array.slice(1));
      setArr2(array.slice(1));
    }
    if (method === "slice4") {
      console.log(array.slice(2));
      setArr2(array.slice(2));
    }
    if (method === "concat") {
      setArr2(array.concat([3, 4]));
    }

    if (method === "reverse") {
      setArr2([...array.reverse()]);
    }
  };
  // var ary = [1, 2, 3, 1, 2, 3, 1, 2, 3, 4, 5, 4]

  // function dublicate(a) {
  //     let b = [1]

  //     console.log(b.includes(1))

  //     a.map((dt, i) => {

  //         if (!b.includes(dt)) { b.push(dt) }

  //     })

  //     console.log(b)

  // }

  // dublicate(ary)

  return (
    <>
      <div className="row">
        <div className="col-12">
          <table className="table table-striped table-hover">
            <tbody>
              <tr className="">
                <td>
                  toString() converts an array to a string of (comma separated)
                  array values.
                </td>{" "}
              </tr>
              <tr className="">
                <td>
                  {" "}
                  The join() method also joins all array elements into a string.
                  It behaves just like toString(), but in addition you can
                  specify the separator:
                </td>
              </tr>

              <tr className="">
                <td> arr.push(...items) – adds items to the end,</td>{" "}
              </tr>
              <tr className="">
                <td> arr.pop() – extracts an item from the end,</td>{" "}
              </tr>
              <tr className="">
                <td> arr.shift() – extracts an item from the beginning,</td>{" "}
              </tr>
              <tr className="">
                <td> arr.unshift(...items) – adds items to the beginning.</td>{" "}
              </tr>

              <tr className="">
                <td>
                  Array elements can be deleted using the JavaScript operator
                  delete. Using delete leaves undefined holes in the array. Use
                  pop() or shift() instead.
                </td>{" "}
              </tr>

              <tr className="">
                <td>
                  The splice() method adds /remove items to an array.
                  <br />
                  fruits.splice(2, 0, "Lemon", "Kiwi"); <br />
                  The first parameter (2) defines the position where new
                  elements should be added (spliced in).
                  <br />
                  The second parameter (0) defines how many elements should be
                  removed. The rest of the parameters ("Lemon" , "Kiwi") define
                  the new elements to be added.
                  <br /> The splice() method returns an array with the deleted
                  items:
                </td>{" "}
              </tr>

              <tr className="">
                <td>
                  <code>
                    {" "}
                    const fruits = ["Banana", "Orange", "Apple", "Mango"];
                    <br /> fruits.splice(0, 1);
                  </code>
                </td>{" "}
              </tr>

              <tr className="">
                <td>
                  The slice() method slices out a piece of an array into a new
                  array.
                </td>{" "}
              </tr>
              <tr className="">
                <td>
                  <code>
                    const fruits = ["Banana", "Orange", "Lemon", "Apple",
                    "Mango"];
                    <br />
                    const citrus = fruits.slice(1);
                  </code>
                </td>{" "}
              </tr>

              <br />
              <br />
            </tbody>
          </table>
        </div>

        <div className="col-12">
          {" "}
          <div className="">
            <div className="mb-3 p-3">
              <div>
                <code>[1, 2, 2, 3, 45, 55, 65, 90, 2, 45]</code>
              </div>
              <code>{JSON.stringify(arr)}</code>
              <br />
              <label className="form-label">Enter Number</label>
              <input
                type="number"
                className="form-control"
                placeholder="222"
                value={value}
                onChange={(e) => setValue(e.target.value)}
              />
            </div>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod("push")}
            >
              Push
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => ArrayMethod("pop")}
            >
              pop
            </button>

            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod("shift")}
            >
              shift
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod("unshift")}
            >
              unshift
            </button>
            <br></br>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod("unique")}
            >
              unique
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod("dublicate")}
            >
              dublicate
            </button>

            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod("ascending")}
            >
              Ascending
            </button>

            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod("decending")}
            >
              Decending
            </button>

            <br></br>

            <div>
              <code>["this", "is", "array", "methods", "learning"]</code>
            </div>
            <code>{JSON.stringify(arr2)}</code>

            <br></br>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("splice5")}
            >
              array.splice(0 ,1)
            </button>

            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("splice")}
            >
              {" "}
              array.splice(1, 1)
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("splice2")}
            >
              array.splice(1, 2)
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("splice3")}
            >
              array.splice(2, 1)
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("splice4")}
            >
              array.splice(2 ,2)
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("splice6")}
            >
              array.splice(2, 2, "x", "y")
            </button>

            <br></br>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("slice")}
            >
              {" "}
              array.slice(0, 3)
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("slice2")}
            >
              {" "}
              array.slice(0, 1)
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("slice3")}
            >
              {" "}
              array.slice(1)
            </button>

            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("slice4")}
            >
              {" "}
              array.slice(2)
            </button>

            <br></br>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("concat")}
            >
              {" "}
              array.concat([3, 4])
            </button>
            <br></br>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => ArrayMethod2("reverse")}
            >
              {" "}
              array.reverse()
            </button>
            <br></br>
            <br></br>
          </div>
        </div>
      </div>

      <br></br>

      <div>
        <p className="fs-1">Array Iteration</p>
        The forEach() method calls a function (a callback function) once for
        each array element.
        <div className="row">
          <div className="col">
            <table className="table table-striped table-hover">
              <thead>
                <tr>
                  <th>forEach()</th> <th>map()</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    {" "}
                    The forEach() method does not returns a new array based on
                    the given array.
                    <br />
                    <code>
                      {" const numbers = [45, 4, 9, 16, 25];"}
                      <br />
                      {' let txt = "";'}
                      <br />
                      {" numbers.forEach(myFunction);"}
                      <br />
                      {"function myFunction(value, index, array)"}'
                      {'txt += value + "<br>"'}
                    </code>
                  </td>
                  <td>The map() method returns an entirely new array.</td>
                </tr>
                <tr>
                  <td> The forEach() method returns “undefined“.</td>{" "}
                  <td>
                    The map() method returns the newly created array according
                    to the provided callback function.
                  </td>
                </tr>
                <tr>
                  <td>
                    The forEach() method doesn’t return anything hence the
                    method chaining technique cannot be applied here.{" "}
                  </td>
                  <td>
                    With the map() method, we can chain other methods like,
                    reduce(),sort() etc.
                  </td>
                </tr>
                <tr>
                  <td>It is not executed for empty elements.</td>
                  <td>It does not change the original array.</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="col"></div>
        </div>
      </div>
      <ul className="list-group list-group-flush">
        <li className="list-group-item">
          <h3> for in </h3>
          gives index
        </li>{" "}
        <li className="list-group-item">
          <h3> for of </h3>
          gives value
        </li>{" "}
        <li className="list-group-item">
          <h3></h3>
        </li>{" "}
        <li className="list-group-item">
          <h3></h3>
        </li>{" "}
        <li className="list-group-item">
          <h3></h3>
        </li>{" "}
        <li className="list-group-item">
          <h3></h3>
        </li>{" "}
        <li className="list-group-item">
          <h3></h3>
        </li>{" "}
        <li className="list-group-item">
          <h3></h3>
        </li>{" "}
        <li className="list-group-item">
          <h3></h3>
        </li>{" "}
        <li className="list-group-item">
          <h3></h3>
        </li>{" "}
        <li className="list-group-item">
          <h3></h3>
        </li>
      </ul>
    </>
  );
};

export default Array;
