import React from "react";

function Redux() {
  return (
    <ul className="list-group list-group-flush">
      <li className="list-group-item">
        <h3>1) What is Redux?</h3>
        Redux is a predictable state container for JavaScript apps based on the
        Flux design pattern. Redux can be used together with ReactJS, or with
        any other view library. It is tiny (about 2kB) and has no dependencies.
      </li>
      <li className="list-group-item">
        <h3>How to add multiple middlewares to Redux?</h3>
        <code>
          {"  import { createStore, applyMiddleware } from 'redux';"}
          <br />

          {
            "const createStoreWithMiddleware = applyMiddleware(ReduxThunk, logger)(createStore);"
          }
        </code>
      </li>{" "}
      <li className="list-group-item">
        <h3>What are reducers in redux?</h3>
        The reducer is a pure function that takes the previous state and an
        action, and returns the next state.
      </li>{" "}
      <li className="list-group-item">
        <h3>What are the core principles of Redux?</h3>
        Redux follows three fundamental principles: <br />
        <b>1. Single source of truth:</b> The state of your whole application is
        stored in an object tree within a single store. The single state tree
        makes it easier to keep track of changes over time and debug or inspect
        the application.
        <br /> <b>2. State is ready only:</b> The only way to change the state
        is to emit an action, an object describing what happened. This ensures
        that neither the views nor the network callbacks will ever write
        directly to the state. <br />
        <b> 3. Changes are made with pure functions:</b> To specify how the
        state tree is transformed by actions, you write pure reducers(Reducers
        are just pure functions that take the previous state and an action, and
        return the next state).
      </li>{" "}
      <li className="list-group-item">
        <h3>What is Redux Thunk?</h3>
        Redux Thunk middleware allows you to write action creators that return a
        function instead of an action. The thunk can be used to delay the
        dispatch of an action, or to dispatch only if a certain condition is
        met. The inner function receives the store methods dispatch and
        getState() as parameters.
      </li>{" "}
      <li className="list-group-item">
        <h3>What is redux-saga?</h3>
        redux-saga is a library that aims to make side effects (i.e.
        asynchronous things like data fetching and impure things like accessing
        the browser cache) in React/Redux applications easier and better.
      </li>{" "}
      <li className="list-group-item">
        <h3>What is the difference between React context and React redux?</h3>
        You can use Context in your application directly and is going to be
        great for passing down data to deeply nested components which what it
        was designed for. Whereas Redux is much more powerful and provides a
        large number of features that the Context Api doesn't provide.
        <br />
        Also, React Redux uses context internally but it doesn’t expose this
        fact in the public API. So you should feel much safer using context via
        React Redux than directly because if it changes, the burden of updating
        the code will be on React Redux instead developer responsibility.
      </li>{" "}
      <li className="list-group-item">
        <h3>How to access redux store outside a react component?</h3>
        Yes.You just need to export the store from the module where it created
        with createStore. Also, it shouldn't pollute the global window object.
      </li>{" "}
      <li className="list-group-item">
        <h3>What are the differences between redux-saga and redux-thunk?</h3>
        Both Redux Thunk and Redux Saga take care of dealing with side effects.
        In most of the scenarios, Thunk allows Promises to deal with them,
        whereas Saga uses Generators.
        <br />
        Thunk is simple to use and Promises are familiar to many developers,
        Saga/Generators are more powerful but you will need to learn them. But
        both the two middleware can coexists, so you can start with Thunks and
        introduce Sagas when/if you need them.
      </li>{" "}
      <li className="list-group-item">
        <h3>What is Redux form?</h3>
        Redux Form works with React and Redux to enable a form in React to use
        Redux to store all of its state. Redux Form can be used with raw HTML5
        inputs, but it also works with very well with common UI frameworks like
        Material UI, React Widgets and React Bootstrap.
      </li>{" "}
      <li className="list-group-item">
        <h3>What is an action in Redux?</h3>
        Actions are the plain JavaScript objects which contain a type field.
        Action can be considered as an event that can describe something that
        has happened in the application.
        <br />
        <code>
          {" const addTodoAction = {"}
          {" type: 'ADD',"}
          {" payload: 'Buy-milk'"}
        </code>
      </li>{" "}
      <li className="list-group-item">
        <h3>What is “store” in redux?</h3>
        The Redux “store” carries together all the states, reducers, and actions
        that create the app. The store has multiple responsibilities:
        <br />
        It holds the state of the current application from inside With the help
        of store.getState();
        <br /> it allows access to the current state. With the help of the
        store.dispatch(action);
        <br /> it allows the state to be updated. With the help of the
        store.subscriber(listener); <br />
        it allows to register listener callbacks.
      </li>{" "}
      <li className="list-group-item">
        <h3>How to access redux stores outside a react component?</h3>
        To access the redux stores outside a react component, you need to export
        the store from the module where it has been created with createStore.
        <br />
        <code>
          store = createStore(myReducer);
          <br />
          export default store;
        </code>
      </li>{" "}
      <li className="list-group-item">
        <h3>Redux using Hooks</h3>
        <code>
          {"//get data from store "}
          <br />
          {"const fruit = useSelector((state) => state.fruitReducer); "} <br />
          <br />
          {" const dispatch= useDispatch();"} <br />
          {"//dispatch data  to store "}
          <br />
          {" dispatch(addFruitsName(fname))"} <br />
          <br />
          <b>{"//Action "}</b>
          <br />
          {"export const addFruitsName = (fname) => {"} <br />
          {"return {"} <br />
          {"type: 'FRUITSNAME',"}
          <br />
          {" payload: fname,"} <br />
          {"};"} <br />
          {"};}"}
          <br />
          <br />
          <b> {"//Reducer "} </b>
          <br />
          {"const inititalState = { fname: 'Apple', quantity: 1 };"} <br />
          {"const fruitReducer = (state = inititalState, action) => {"} <br />
          {"switch (action.type) {"} <br />
          {"   case 'FRUITSNAME': {"} <br />
          {"  return { ...state, fname: action.payload };"}
          {" }"} <br />
          {" return state;"} <br />
          {"};"} <br />
          <br />
          <b> {"//Store "}</b>
          <br />
          {'import fruitReducer from "./reducers/fruitReducer";'} <br />
          {"const store = configureStore({"} <br />
          {"  reducer: { fruitReducer }"} <br />
          {"});"}
          <br />
          <br />
          <b> {"//index.js "}</b>
          <br />
          {' import store from "./Redux/store";'} <br />
          {'import { Provider } from "react-redux";'} <br />
          {"root.render("} <br />
          {"<Provider store={store}>"} <br />
          {"<App />"} <br />
          {" </Provider>"} <br />
          {")"}
        </code>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>
    </ul>
  );
}

export default Redux;
