import React from "react";
import img from "../image/box-model.png";

function Css() {
  return (
    <ul className="list-group list-group-flush">
      <li className="list-group-item">
        <h3>1) What is the CSS Box model and what are its elements?</h3>
        The CSS box model is used to define the design and layout of elements of
        CSS. The elements are:
        <br /> Margin - It removes the area around the border. It is
        transparent.
        <br /> Border - It represents the area around the padding
        <br /> Padding - It removes the area around the content. It is
        transparent. <br /> Content - It represents the content like text,
        images, etc.
        <br />
        <img src={img} />
      </li>
      <li className="list-group-item">
        <h3>What are pseudo-elements in CSS?</h3>A CSS pseudo-element is a
        keyword added to a selector that lets you style a specific part of the
        selected element(s). They can be used for decoration (:first-line,
        :first-letter) or adding elements to the markup (combined with content:
        ...) without having to modify the markup (:before, :after).
      </li>
      <li className="list-group-item">
        <h3>
          What’s the difference between a relative, fixed, absolute and
          statically positioned element?
        </h3>
        Static The default position; the element will flow into the page as it
        normally would. The top, right, bottom, left and z-index properties do
        not apply.
        <br />
        Relative <br />
        The element’s position is adjusted relative to itself, without changing
        the layout (and thus leaving a gap for the element where it would have
        been had it not been positioned).
        <br />
        Absolute <br />
        The element is removed from the flow of the page and positioned at a
        specified position relative to its closest positioned ancestor if any,
        or otherwise relative to the initial containing block. Absolutely
        positioned boxes can have margins, and they do not collapse with any
        other margins. These elements do not affect the position of other
        elements.
        <br />
        Fixed <br />
        The element is removed from the flow of the page and positioned at a
        specified position relative to the viewport and doesn’t move when
        scrolled.
        <br />
        Sticky <br />
        Sticky positioning is a hybrid of relative and fixed positioning. The
        element is treated as relative positioned until it crosses a specified
        threshold, at which point it is treated as fixed positioned.
      </li>
      <li className="list-group-item">
        <h3> Display flex container properties are </h3>
        <br />
        <b>flex-direction</b> <br />
        <code>
          flex-direction: column; <br />
          flex-direction: column-reverse; <br />
          flex-direction: row; <br />
          flex-direction: row-reverse;
        </code>
        <br />
        <b>flex-wrap </b>
        <br />
        <code>
          flex-wrap: wrap;
          <br />
          flex-wrap: nowrap;
          <br/>
          flex-wrap: wrap-reverse;

          <br />
          flex-wrap: row-wrap;
        </code>
        <br />
        <b>flex-flow</b> <br />
        <b>justify-content </b> <br />
        align-items <br />
        align-content <br />
      </li>{" "}
      <li className="list-group-item">
        <h3> What are Inline Elements?</h3>
        Inline elements take only the required width. Those elements do not
        start with a new line example:- a , i , b, img
      </li>{" "}
      <li className="list-group-item">
        <h3> What are Block Elements?</h3>
        The block elements take all width. Those elements start with a new line
        example:- p ,h1 ,ul ,hr
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>
    </ul>
  );
}

export default Css;
