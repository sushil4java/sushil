import React from "react";

function ReactBasics() {
  return (
    <ul className="list-group list-group-flush">
      <li className="list-group-item">
        <h3>1) What is React?</h3>
        React is a declarative, efficient, flexible open source front-end
        JavaScript library developed by Facebook in 2011. It follows the
        component-based approach for building reusable UI components, especially
        for single page application.
        <br /> It was created by Jordan Walke, a software engineer at Facebook.
        It was initially deployed on Facebook's News Feed section in 2011 and
        later used in its products like WhatsApp & Instagram.
      </li>
      <li className="list-group-item">
        <h3>2) What are the features of React?</h3>
        JSX <br />
        Components <br /> One-way Data Binding <br /> Virtual DOM <br />{" "}
        Simplicity <br />
        Performance
      </li>
      <li className="list-group-item">
        <h3>3) What is JSX?</h3>
        JSX stands for JavaScript XML. It is a React extension which allows
        writing HTML inside JavaScript.
      </li>
      <li className="list-group-item">
        <h3> 4) Why can't browsers read JSX? </h3>
        Browsers cannot read JSX directly because they can only understand
        JavaScript objects, and JSX is not a regular JavaScript object. Thus, we
        need to transform the JSX file into a JavaScript object using
        transpilers like Babel and then pass it to the browser.
      </li>{" "}
      <li className="list-group-item">
        <h3>5) Explain the working of Virtual DOM.</h3>
        1. Whenever any data changes in the React App, the entire UI is
        re-rendered in Virtual DOM representation.
        <br />
        2. Now, the difference between the previous DOM representation and the
        new DOM is calculated. <br />
        3. Once the calculations are completed, the real DOM updated with only
        those things which are changed.
      </li>{" "}
      <li className="list-group-item">
        <h3> 6)What is the difference between Real DOM and Virtual DOM?</h3>

        <table className="table table-striped table-hover">
          <thead>
            <tr>
              <th>Real DOM</th> <th>Virtual DOM</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>The real DOM updates slower. </td>{" "}
              <td>The real DOM updates faster. </td>
            </tr>
            <tr>
              <td> There is a lot of memory wastage in The real DOM.</td>{" "}
              <td> There is no memory wastage in the virtual DOM.</td>
            </tr>
            <tr>
              <td>The real DOM can directly update HTML. </td>{" "}
              <td> The real DOM can not directly update HTML.</td>
            </tr>
          </tbody>
        </table>
      </li>{" "}
      <li className="list-group-item">
        <h3>7)Differentiate between States and Props</h3>
        <table className="table table-striped table-hover">
          <thead>
            <tr>
              <th>States</th> <th>props</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td> State changes can be asynchronous.</td>{" "}
              <td>Props are read-only.</td>
            </tr>
            <tr>
              <td> State is mutable.</td> <td> Props are immutable.</td>
            </tr>
          </tbody>
        </table>
      </li>{" "}
      <li className="list-group-item">
        <h3> Differentiate between stateless and stateful components.</h3>

        <table className="table table-striped table-hover">
          <thead>
            <tr>
              <th>stateless components</th> <th>stateful components</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td> It is also known as a functional component.</td>{" "}
              <td> It is also known as a class component.</td>
            </tr>
            <tr>
              <td>The stateless components do not hold or manage state.</td>{" "}
              <td>The stateful components can hold or manage state.</td>
            </tr>
          </tbody>
        </table>
      </li>{" "}
      <li className="list-group-item">
        <h3> What are synthetic events in React?</h3>A synthetic event is an
        object which acts as a cross-browser wrapper around the browser's native
        event. It combines the behavior of different browser's native event into
        one API, including stopPropagation() and preventDefault(). <br />{" "}
        example, e is a Synthetic event. like e.preventDefault()
        e.stopPropagation()
      </li>{" "}
      <li className="list-group-item">
        <h3>
          what is the difference between controlled and uncontrolled components?
        </h3>
        <table className="table table-striped table-hover">
          <thead>
            <tr>
              <th>controlled components</th> <th>uncontrolled components</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>It does not maintain its internal state.</td>{" "}
              <td>It maintains its internal states.</td>
            </tr>
            <tr>
              <td>Here, data is controlled by the parent component.</td>
              <td>Here, data is controlled by the DOM itself.</td>
            </tr>
            <tr>
              <td>
                It accepts its current value as a prop.
                <br />
                // Controlled:
                <br />
                <code>
                  {
                    "<input type='text' value={value} onChange={handleChange} />"
                  }
                </code>
              </td>
              <td>
                {" "}
                It uses a ref for their current values
                <br />
                // Uncontrolled:
                <br />
                <code>
                  {"<input type='text' defaultValue='foo' ref={inputRef} />"}
                </code>
              </td>
            </tr>{" "}
            <tr>
              <td>It has better control over the form elements and data.</td>
              <td>It has limited control over the form elements and data.</td>
            </tr>{" "}
            <tr>
              <td></td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </li>{" "}
      <li className="list-group-item">
        <h3> What are Pure Components?</h3>
        It stops the aggressive re-rendering cycle. PureComponent does not
        re-render unless its props and state change using
        shouldComponentUpdate() React lifecycle method. This method decides the
        re-rendering of the component by returning a boolean value (true or
        false).
        <br /> In React.Component, shouldComponentUpdate() method returns true
        by default.
        <br />
        Example:-
        <br />
        export default class Test extends React.PureComponent
      </li>{" "}
      <li className="list-group-item">
        <h3>What are Higher Order Components(HOC)?</h3>
        Higher-order components or HOC is the advanced method of reusing the
        component functionality logic.
        <br />
        It simply takes the original component and returns the enhanced
        component
        <code>
          {" "}
          <br />
          Example:-
          <br />
          const NewComponent = higherOrderComponent(WrappedComponent);
          <br />
          or
          <br />
          const EnhancedComponent = higherOrderComponent(OriginalComponent);
        </code>
      </li>{" "}
      <li className="list-group-item">
        <h3>Code Splitting/Lazy Loading</h3>
        Code splitting uses React.lazy and Suspense tool/library, which helps
        you to load a dependency lazily and only load it when needed by the
        user.
        <code>
          {" "}
          {"import React, { Suspense, lazy } from 'react';  "}
          <br />
          {"const MyComponent = lazy(() => import('./MyComponent.js'));"}
          <br />
          {"<Suspense fallback={<div>Loading...</div>}>"}
          <br />
          {" <MyComponent />"}
          <br />
          {"</Suspense>"}
        </code>
      </li>{" "}
      <li className="list-group-item">
        <h3>Error boundaries</h3>
        If any module fails to load, for example, due to network failure, we
        will get an error. We can handle these errors with Error Boundaries
        <br />
        {"<ErrorBoundary>"}
        <br />
        {"    <Component/>"}
        <br />
        {"</ErrorBoundary>"}
      </li>{" "}
      <li className="list-group-item">
        <h3>What do you understand by refs in React?</h3>
        Refs is the shorthand used for references in React.
        <br />
        It is used to return a reference to the element.
        <br />
        It is used when we need DOM measurements such as managing focus, text
        selection, or media playback.
      </li>{" "}
      <li className="list-group-item">
        <h3>What are the rules you should follow for the hooks in React?</h3>
        We have to follow the following two rules to use hooks in React:
        <br />
        1). You should call hooks only at the top level of your React functions
        and not inside the loops, conditions, or nested functions.
        <br />
        2). You should call hooks from React functions only. Don't call hooks
        from regular JavaScript functions
        <br />
      </li>{" "}
      <li className="list-group-item">
        <h3>React Context API</h3>
        The React Context API is a component structure, which allows us to share
        data across all levels of the application. The main aim of Context API
        is to solve the problem of prop drilling (also called "Threading"). The
        Context API in React are given below.
        <br />
        1). React.createContext
        <br />
        const MyContext = React.createContext(defaultValue);
        <br />
        2). Context.provider
        <br />
        {"<MyContext.Provider value={/* some value */}> "}
        <br />
        3). Context.Consumer
        <br />
        {"<MyContext.Consumer>  "}
        <br />
        {
          "{value => /* render something which is based on the context value */}"
        }
        <br />
        {"</MyContext.Consumer> "}
        <br />
        4). Class.contextType
      </li>{" "}
      <li className="list-group-item">
        <h3>Design Pattern React</h3>
        <br />
        Functional vs. Container Components <br />
        Compound Components <br />
        Conditional Rendering <br />
        Render Props <br />
        Controlled Components <br />
        React Hooks <br />
        Higher-Order Component Pattern <br />
      </li>{" "}
      <li className="list-group-item">
        <h3>MVC architecture in react </h3>
        The difference between MVC and Flux is that latest implements
        unidirectional data flow. So your data can move only one direction.{" "}
        <br />
        Action - Middleware - Store - View. <br /> MVC is bidirectional; you can
        change Model from View and from Controller.
      </li>{" "}
      <li className="list-group-item">
        <h3>Flux in react</h3>
        Flux is a programming concept, where the data is uni-directional. This
        data enters the app and flows through it in one direction until it is
        rendered on the screen. Flux Elements Following is a simple explanation
        of the flux concept. In the next chapter, we will learn how to implement
        this into the app.
        <br /> Actions − Actions are sent to the dispatcher to trigger the data
        flow.
        <br /> Dispatcher − This is a central hub of the app. All the data is
        dispatched and sent to the stores.
        <br /> Store − Store is the place where the application state and logic
        are held. Every store is maintaining a particular state and it will
        update when needed.
      </li>{" "}
      <li className="list-group-item">
        <h3>useMemo</h3>
        The React useMemo Hook returns a memoized value.
        <br />
        The useMemoHook accepts a second parameter to declare dependencies. The
        expensive function will only run when its dependencies have changed.
        <br />
        <code>
          {"   const expensiveCalculation=()=>{code }};"}
          <br />
          {
            "  const calculation = useMemo(() => expensiveCalculation(count), [count]);"
          }
        </code>
      </li>{" "}
      <li className="list-group-item">
        <h3>What is shallow copy and deep copy in JavaScript ?</h3>
        <b>Shallow Copy:</b> When a reference variable is copied into a new
        reference variable using the assignment operator, a shallow copy of the
        referenced object is created.
        <br /> In simple words, a reference variable mainly stores the address
        of the object it refers to. When a new reference variable is assigned
        the value of the old reference variable, the address stored in the old
        reference variable is copied into the new one.
        <br />
        <code>
          {"  var employee = {"} <br />
          {"   eid: 'E102',"}
          <br />
          {"   ename: 'Jack',"}
          <br />
          {"   eaddress: 'New York',"}
          <br />
          {"    salary: 50000"}
          <br />
          {" }"}
          <br />
          {" var newEmployee = employee;    // Shallow copy"}
          <br />
          {
            "var newEmployee = JSON.parse(JSON.stringify(employee));   // deep copy"
          }
        </code>
        <br />
        <b>Deep Copy:</b>
        makes a copy of all the members of the old object, allocates separate
        memory location for the new object and then assigns the copied members
        to the new object.
      </li>{" "}
      <li className="list-group-item">
        <h3>useCallback hook</h3>
        The useCallback Hook only runs when one of its dependencies update.
        <br />
        The useCallback and useMemo Hooks are similar. The main difference is
        that useMemo returns a memoized value and useCallback returns a memoized
        function.
        <code>
          {"const [delta, setDelta] = useState(1);"}
          <br />
          {"const [c, setC] = useState(0);"}
          <br />
          {
            " const incrementDelta = useCallback(() => setDelta(delta => delta + 1), []);"
          }
          <br />

          {"// Recreate increment on every change of delta!"}
          <br />
          {
            "const increment = useCallback(() => setC(c => c + delta), [delta]);"
          }
          <br />
        </code>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>{" "}
      <li className="list-group-item">
        <h3></h3>
      </li>
    </ul>
  );
}

export default ReactBasics;
