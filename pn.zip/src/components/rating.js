import React, { useEffect, useState } from "react";
const Rating = () => {
  const [rate, setRate] = useState();
  var rating = [
    { id: 1, selected: false },
    { id: 2, selected: false },
    { id: 3, selected: false },
    { id: 4, selected: false },
    { id: 5, selected: false },
  ];

  const setRating = (val) => {
    for (var i = 0; i <= val; i++) {
      rating[i].selected = true;
    }

    setRate(rating);
  };
  useEffect(() => {
    setRating();
  }, []);

  return (
    <div className="text-center fs-1">
      {rate &&
        rate.map((data, i) => (
          <span
            key={i}
            style={{ cursor: "pointer" }}
            onClick={() => setRating(i)}
          >
            {data.selected ? <span>&#9733;</span> : <span>&#9734;</span>}
            {/* {data.id} */}
          </span>
        ))}
  </div>  
  );
};
export default Rating;
