import React from "react";

function html() {
  return (
    <ul className="list-group list-group-flush">
      <li className="list-group-item">
        <h3>1) What is React?</h3>
      </li>
    </ul>
  );
}

export default html;
