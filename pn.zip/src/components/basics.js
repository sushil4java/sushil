import React from "react";

export default function Basics() {
  return (
    <>
      <ul>
        <li className="list-group-item">
          JavaScript has 8 Datatypes
          <br />
          1. String
          <br />
          2. Number <br />
          3. Bigint //(new datatype (2020)) <br />
          4. Boolean <br />
          5. Undefined <br />
          5. Null
          <br /> 7. Symbol
          <br /> 8. Object
          <br />
        </li>{" "}
        <li className="list-group-item">
          JavaScript evaluates expressions from left to right. Different
          sequences can produce different results:
          <br />{" "}
          <code>
            let x = 16 + 4 + "Volvo";
            <br />
            Result: 20Volvo
            <br />
            let x = "Volvo" + 16 + 4; <br />
            Result: Volvo164
          </code>
        </li>
        <li className="list-group-item">
          <div className="row">
            <div className="col">
              <p className="fs-1">JavaScript String Methods</p>
              String length
              <br /> String slice()
              <br /> String substring()
              <br /> String substr()
              <br />
              String replace()
              <br /> String replaceAll()
              <br /> String toUpperCase()
              <br /> String toLowerCase()
              <br /> String concat()
              <br /> String trim()
              <br /> String trimStart()
              <br />
              String trimEnd()
              <br /> String padStart()
              <br /> String padEnd()
              <br /> String charAt()
              <br />
              String charCodeAt()
              <br /> String split()
              <br />
            </div>
            <div className="col">
              <p className="fs-1">JavaScript String Search Methods</p>
              String indexOf()
              <br /> String lastIndexOf()
              <br /> String search()
              <br /> String match()
              <br /> String matchAll()
              <br /> String includes()
              <br /> String startsWith()
              <br />
              String endsWith()
              <br />
            </div>
          </div>
          <div className="row">
            <p className="fs-1">JavaScript Number Methods</p>
            toString() // Returns a number as a string <br />
            toExponential() // Returns a number written in exponential notation{" "}
            <br />
            toFixed() // Returns a number written with a number of decimals
            <br /> toPrecision() // Returns a number written with a specified
            length <br />
            ValueOf() // Returns a number as a number
          </div>
        </li>
        <p className="fs-1">let</p>
        <li className="list-group-item">
          The <b>let</b> keyword was introduced in ES6 (2015).{" "}
        </li>
        <li className="list-group-item">
          {" "}
          Variables defined with <b>let</b> cannot be Redeclared.
          <br />
          <code>
            let x = "John Doe";
            <br />
            let x = 0; // SyntaxError: 'x' has already been declared
          </code>{" "}
        </li>
        <li className="list-group-item">
          {" "}
          Variables defined with <b>let</b> must be Declared before use.{" "}
        </li>
        <li className="list-group-item">
          {" "}
          Variables defined with <b>let</b> have Block Scop
          <br />
          <code>
            &#123;
            <br />
            let x = 2;
            <br />
            &#125;
            <br />
            // x can NOT be used here{" "}
          </code>
        </li>
      </ul>
      <ul>
        {" "}
        <p className="fs-1">const</p>
        <li className="list-group-item">
          The <b>const</b> keyword was introduced in ES6 (2015).{" "}
        </li>
        <li className="list-group-item">
          {" "}
          Variables defined with <b>const</b> cannot be Redeclared.
        </li>
        <code>
          const PI = 3.141592653589793;
          <br />
          PI = 3.14; // This will give an error
          <br />
          <br />
        </code>
        <li className="list-group-item">
          {" "}
          Variables defined with <b>const</b> cannot be Reassigned.
        </li>
        <li className="list-group-item">
          {" "}
          Variables defined with <b>const</b> have Block Scope.{" "}
        </li>
        <li className="list-group-item">
          JavaScript const variables must be assigned a value when they are
          declared:
          <br />
          <code>
            <b className="text-success">Correct</b>
            <br />
            const PI = 3.14159265359;
            <br />
            <b className="text-warning">Incorrect</b>
            <br />
            const PI;
            <br />
            PI = 3.14159265359;
          </code>
        </li>
        <li className="list-group-item">
          We can not:
          <br />
          # Reassign a value
          <br />
          # Reassign a array
          <br />
          # Reassign a object
          <br />
          <code>
            const cars = ["Saab", "Volvo", "BMW"];
            <div className="text-warning">
              {" "}
              cars = ["Toyota", "Volvo", "Audi"]; // ERROR
            </div>
          </code>
        </li>
        <li className="list-group-item">
          But we can:
          <br />
          # Change the elements of constant array
          <br /># Change the properties of constant object
          <code>
            <br />
            // We can create a constant array:
            <br />
            const cars = ["Saab", "Volvo", "BMW"];
            <br />
            // We can change an element:
            <br />
            cars[0] = "Toyota";
            <br />
            // We can add an element:
            <br />
            cars.push("Audi");
          </code>
        </li>
        <li className="list-group-item">
          <h3>constructor</h3>
          Objects of the same type are created by calling the constructor
          function with the new keyword:
          <br />
          <code>
            {"// function constructor"} <br />
            {"function Person(first, last) {"} <br />
            {"this.firstName = first;"} <br />
            {"this.lastName = last;"} <br />
            {" }"} <br />
            {"// Create a Person object"} <br />
            {'const myFather = new Person("John", "Doe");'} <br />
            {'const myUncle = new Person("Johnny", "walker");'}
          </code>
        </li>
        <li className="list-group-item">
          <h3>Prototype</h3>
          Prototype property is basically an object (also known as Prototype
          object), where we can attach methods and properties in a prototype
          object, which enables all the other objects to inherit these methods
          and properties.
          <code>
            {"// function constructor"} <br />
            {"function Person(first, last) {"} <br />
            {"this.firstName = first;"} <br />
            {"this.lastName = last;"} <br />
            {" }"} <br />
            {""} <br />
            {' Person.prototype.nationality = "English";'} <br />
            {"Person.prototype.calculateAge= function(){"} <br />
            {"//your function"} <br />
            {"}"} <br />
          </code>
        </li>{" "}
        <li className="list-group-item">
          <h3>Generator</h3>
          Uses of Generators
          <br />
          Generators let us write cleaner code while writing asynchronous tasks.
          <br />
          Generators provide an easier way to implement iterators.
          <br />
          Generators execute its code only when required.
          <br />
          Generators are memory efficient.
          <br />
          Generators were introduced in ES6. <br />
          <br />
          There are three methods mainly associated with generators. <br />
          1.)<b> next()</b>: It returns the value of yield. <br />
          2.)<b> return()</b>: It returns the value and then terminates the
          generator function. <br />
          <code>
            {"  // generator function "} <br />
            {"function* generatorFunc() {"} <br />
            {" yield 100;"} <br />
            {"return 123;"} <br />
            {
              'console.log("2. some code before second yield"); //this line will not print because of return'
            }{" "}
            <br />
            {"  yield 200;"} <br />
            {"}"} <br />
            {"// returns generator object"} <br />
            {"const generator = generatorFunc();"} <br />
            {"console.log(generator.next());//{ value: 100, done: false }"}{" "}
            <br />
            {"console.log(generator.next());//{ value: 123, done: true }"}{" "}
            <br />
            {
              "console.log(generator.next());//{ value: undefined, done: true }"
            }{" "}
            <br />
          </code>
          3.)<b> throw() </b>: It throws an error and then ends the generator
          function. // generator function
          <br />
          <code>
            {"function* generatorFunc() { "} <br />
            {" yield 100;"} <br />
            {" yield 200;"} <br />
            {"}"} <br />
            {"// returns generator object"} <br />
            {"const generator = generatorFunc();"} <br />
            {"console.log(generator.next());"} <br />
            {"// throws an error"} <br />
            {"// terminates the generator"} <br />
            {'console.log(generator.throw(new Error("Error occurred.")));'}{" "}
            <br />
            {"console.log(generator.next());"} <br />
          </code>
          <br />
          <br />
        </li>
        <li className="list-group-item">
          <h3>Promise.all()</h3>
          Parallel API Calls To avoid slow execution, we can send all the API
          calls at once and execute them in parallel. As a result, there is no
          particular order in which the calls finish their execution, but their
          execution times do not add up since they run together.
          <br />
          <br /> The Promise.all() method takes an array of promises as an input
          and returns a single promise that resolves to the results of all the
          input promises. Every API call is essentially a promise, so we can
          feed all the API calls in Promise.all(), which will execute them
          together.
          <code>
            {"const callPost = async () => { "}
            <br />
            {"const ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]; // Array of ids"}
            <br />
            {"const responses = await Promise.all( "}
            <br />
            {" ids.map(async (id) => {"}
            <br />
            {"  const res = await fetch("}
            <br />
            {"   `https://jsonplaceholder.typicode.com/posts/${id}`"}
            <br />
            {"  ); // Send request for each id"}
            <br />
            {"  })"}
            <br />
            {" );"}
            <br />
            {"};"}
            <br />
          </code>
          One thing to note is that Promise.all() will reject entirely even if
          one of the API calls fails. To avoid this, you can use the
          Promise.allSettled() method, which resolves even when all promises are
          rejected. It includes the status(resolved or rejected) of promises in
          the result.
        </li>
      </ul>
    </>
  );
}
